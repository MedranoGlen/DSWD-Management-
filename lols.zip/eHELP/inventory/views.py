from django.shortcuts import render
from django.db.models import Sum
from django.http import JsonResponse 
from django.contrib.auth.decorators import login_required

from store.models import Product, Supplier, Buyer, Season



@login_required(login_url='login')
def dashboard(request):
    products = Product.objects.all()
    sortnos = Product.objects.all().count()
    total_product = Product.objects.count()
    total_supplier = Supplier.objects.count()
    total_buyer = Buyer.objects.count()
    total_season = Season.objects.count()
    total_ag = Product.objects.filter(sortno='Aguada').count()
    cs_no = Supplier.objects.filter(address__iexact ='Solo').count()
    cs_no = int(cs_no)
    print('Number of Solo Are',cs_no)
    ce_no = Supplier.objects.filter(address__iexact ='Pulong Niogan').count()
    ce_no = int(ce_no)
    print('Number of P.Niogan Are',ce_no)
    cf_no = Supplier.objects.filter(address__iexact ='Mainit').count()
    cf_no = int(cf_no)
    print('Number of Mainit Are',cf_no)
    cg_no = Supplier.objects.filter(address__iexact ='Malimatoc 1').count()
    cg_no = int(cg_no)
    print('Number of Malimatoc 1 Are',cg_no)
    address_list = ['Solo', 'P.Niogan', 'Mainit', 'Malimatoc1']
    number_list = [
        cs_no, 
        ce_no, 
        cf_no, 
        cg_no ]
    
    context = {
        'total_ag':total_ag, 
        'products':products, 
        'Pwd': total_product,
        'Youth': total_supplier,
        'women': total_buyer,
        'elder': total_season,
        'address_list':address_list, 
        'number_list':number_list, 
        
    }
    return render(request, 'dashboard.html', context)



def myChart(request):
  labels = []
  data = []
  
  queryset = Product.objects.values('sortno').annotate(sortno-sum('sortno')).order_by('-sortno')
  for entry in queryset:
    labels.append(entry('sortno'))
    data.append(entry('sortno'))
  return JsonResponse(data={
    'labels' : labels, 
    'data' : data, 
 })
    
 

